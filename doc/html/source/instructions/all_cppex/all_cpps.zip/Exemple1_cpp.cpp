#pragma cling add_include_path("/home/assia/miniconda3/envs/xeus-cpp-env/include")
#pragma cling add_include_path("/home/assia/miniconda3/envs/xeus-cpp-env/include/marmoteCore")
#pragma cling add_include_path("/home/assia/miniconda3/envs/xeus-cpp-env/include/marmoteMarkovChain")
#pragma cling add_library_path("/home/assia/miniconda3/envs/xeus-cpp-env/lib")

// Charger explicitement les libs .so
#pragma cling load("libmarmoteCore.so")
#pragma cling load("libmarmoteMarkovChain.so")

int main(int argc, char** argv)
{
#include <marmoteMarkovChain/marmoteMarkovChain.h>
#include <marmoteMarkovChain/marmoteSimulationResult.h>
#include <marmoteCore/marmoteDiscreteDistribution.h>
#include <marmoteCore/marmoteSparseMatrix.h>
#include <iostream>
int main(int argc, char** argv)
{
unsigned int n = 10;
double prob1 = 0.1, prob2 = 0.2, prob3 = 0.7;
double states[3] = {0, 1, 2};
double* probas = new double[3]{prob1, prob2, prob3};
DiscreteDistribution* initial = new DiscreteDistribution(3, states, probas);
MarkovChain* c1 = new MarkovChain(3, DISCRETE);
c1->set_init_distribution(initial);
SparseMatrix* P = new SparseMatrix(3);
P->set_type(DISCRETE);
P->addToEntry(0,0,0.25); P->addToEntry(0,1,0.5);  P->addToEntry(0,2,0.25);
P->addToEntry(1,0,0.4);  P->addToEntry(1,1,0.2);  P->addToEntry(1,2,0.4);
P->addToEntry(2,0,0.4);  P->addToEntry(2,1,0.3);  P->addToEntry(2,2,0.3);
c1->set_generator(P);
c1->Write(&std::cout);
SimulationResult* simRes1 = c1->SimulateChainDT(n, false, true, false);
std::cout << "Trajectory\n";
simRes1->WriteTrajectory(&std::cout, "standard");
std::cout << std::endl;
delete simRes1;
delete c1;
delete initial;
delete[] probas;





}
