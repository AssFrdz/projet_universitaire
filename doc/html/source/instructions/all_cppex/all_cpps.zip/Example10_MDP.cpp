#pragma cling add_include_path("/home/assia/miniconda3/envs/xeus-cpp-env/include")
#pragma cling add_include_path("/home/assia/miniconda3/envs/xeus-cpp-env/include/marmoteCore")
#pragma cling add_include_path("/home/assia/miniconda3/envs/xeus-cpp-env/include/marmoteMDP")
#pragma cling add_library_path("/home/assia/miniconda3/envs/xeus-cpp-env/lib")

// Charger explicitement les libs .so
#pragma cling load("libmarmoteCore.so")
#pragma cling load("libmarmoteMarkovChain.so")

int main(int argc, char** argv)
{
#include <marmoteCore/marmoteSparseMatrix.h>
#include <marmoteCore/marmoteInterval.h>
#include <marmoteMDP/marmoteDiscountedMDP.h>
#include <marmoteMDP/marmoteFeedbackSolutionMDP.h>
#include <marmoteMDP/marmoteSolutionMDP.h>
int main(int argc, char** argv)
{
|  0.2 |  0.8 |
|  0.7 |  0.3 |
MarmoteSet* stateSpace = new MarmoteInterval(0, 1);
MarmoteSet* actionSpace = new MarmoteInterval(0, 1);
vector<SparseMatrix*> trans(actionSpace->Cardinal());
SparseMatrix* P0 = new SparseMatrix(2);

P0->setEntry(0, 0, 0.6);
P0->setEntry(0, 1, 0.4);
P0->setEntry(1, 0, 0.5);
P0->setEntry(1, 1, 0.5);

trans[0] = P0;

SparseMatrix* P1 = new SparseMatrix(2);
P1->setEntry(0, 0, 0.2);
P1->setEntry(0, 1, 0.8);
P1->setEntry(1, 0, 0.7);
P1->setEntry(1, 1, 0.3);

trans[1] = P1;
FullMatrix* Reward = new FullMatrix(2, 2);

Reward->setEntry(0, 0, 4.5);
Reward->setEntry(0, 1, 2);
Reward->setEntry(1, 0, -1.5);
Reward->setEntry(1, 1, 3);
double beta = 0.95;
string criterion = "max";
DiscountedMDP* mdp = new DiscountedMDP(criterion, stateSpace, actionSpace, trans, Reward, beta);
mdp->Write();
FeedbackSolutionMDP* optimum = mdp->ValueIteration(epsilon, maxIter);
optimum->Write();

FeedbackSolutionMDP* optimum2 = mdp->ValueIterationGS(epsilon, 10);
optimum2->Write();

FeedbackSolutionMDP* optimum3 = mdp->ValueIterationInit(epsilon, 200, optimum2);
cout << "Optimum3" << std::endl;
optimum3->Write();

FeedbackSolutionMDP* optimum4 = mdp->PolicyIterationModified(epsilon, maxIter, 0.001, 100);
cout << "Optimum4" << std::endl;
optimum4->Write();

mdp->changeVerbosity(true);

FeedbackSolutionMDP* optimum5 = mdp->PolicyIterationModifiedGS(epsilon, maxIter, 0.01, 20);
cout << "Optimum5" << std::endl;
optimum5->Write();
mdp1->ClearRew();

delete mdp;
delete optimum;
delete optimum2;
delete optimum3;
delete optimum4;
delete optimum5;
delete actionSpace;
delete stateSpace;
delete P0;
delete P1;
}
