#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#Marmote and MarmoteMDP and pyMarmoteMDP are free softwares: you can redistribute it and/or modify
#it under the terms of the GNU General Public License as published by
#the Free Software Foundation, either version 3 of the License, or
#(at your option) any later version.

#Marmote is distributed in the hope that it will be useful,
#but WITHOUT ANY WARRANTY  without even the implied warranty of
#MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#GNU General Public License for more details.

#You should have received a copy of the GNU General Public License
#along with MarmoteMDP. If not, see <http://www.gnu.org/licenses/>.

#Copyright 2023 Emmanuel Hyon, Alain Jean-Marie



"""
 * @brief python code to implement the discounted MDP described by the admission in Service model proposed by Hyon
 *  and Jean-Marie in Computer Journal in 2012
 * @author Hyon,
 * @date Oct 2023
 * @version 1.0
 *
 * Impatience discrete
 * The MDP comes from the article Scheduling Services in a Queuing System with Impatience and Setup Costs.
 *  Computer Journal 2012
 *
 *
"""


# import the library
import math as mt
from marmote.core import *
from marmote.mdp import *

class Problem :

        def __init__(self) :
                self.alpha=1.0     # rate of impatience
                self.lambdaa=1.0   # rate of arrivals
                self.gamma=0.5     # discount rate
                self.batchCost=1.5 # cost of shipping a batch
                self.lossCost=2.0  # cost of a loss
                self.holdingCost=0.0 # cost of keeping a customer in the queue
                self.qCost=(self.alpha*self.lossCost)+self.holdingCost  # cost cQ of the article
                self.nbServ=3      # size of the batch
                self.maxQueueLength=10 # max size of the queue

        def __str__(self) :
                s= "## Optimal batch control problem\n"
                s+="# Max queue size = " + str(self.maxQueueLength)+ "\n"
                s+="# Batch size     = "  + str(self.nbServ)+ "\n"
                s+="# Batch cost     = " + str(self.batchCost)+ "\n"
                s+="# Loss cost      = " + str(self.lossCost)+ "\n"
                s+="# Holding cost   = " + str(self.holdingCost)+ "\n"
                s+="# cost cQ   = " + str(self.qCost)+ "\n"
                s+="# Parameters:\n"
                s+="# lambda (customers/slot) =" + str(self.lambdaa)+ "\n"
                s+="# Alpha = " + str(self.alpha)+ "\n"
                s+="# Discount = " + str(self. gamma)+ "\n"
                s+="#"+ "\n"

                slope = self.qCost / (1.0 - (1.0-self.alpha)*self.gamma)
                psi = self.batchCost - slope
                s+="# Critical parameters of psi\n"
                s+="# slope = " + str(slope)+ "\n"
                s+="# psi = "+ str(psi)+ "\n"
                s+="#############################" + "\n"

                return s



# *********************************************************************
def factorielle(p):
        tempo=1.0
        for i in range(p):
                tempo=tempo*(i+1)
        return tempo


def combinaison(q,n) :
        if (n<q) :
                return 0.0
        else :
                return mt.factorial(n)/(mt.factorial(q)*mt.factorial(n-q))


#return binomiale proba of x=K for x follows b(p,n)
def binomiale(k,n,p) :
        return (mt.pow(p,k)*mt.pow((1-p),(n-k)))*combinaison(k,n)


def poisson(k,lam):
        if (k <0) :
                return 0
        else :
                return (mt.exp((-1)*lam)*mt.pow(lam,k)) / mt.factorial(k)


# *********************************************************************
# *********************************************************************
# variable for storing values are
# cost action proba


# variables to store
# the different states are x,y,xt
# k,l
# store the decision q

# create and initialize the MDP parameters discount factor and criteria.
critere="min"
epsilon = 0.000001
maxIter = 500


# create the default problem
defProb= Problem()
defProb.nbServ=1


# Create the elements of the MDP
# Create the MDP states.
actionSpace = MarmoteInterval(0,defProb.nbServ)
stateSpace = MarmoteInterval(0,defProb.maxQueueLength)

#Create the vector for the transition structures (here matrices)
trans=list()

# variable to manage distributions
#poisson=PoissonDistribution(defProb.lambdaa)


print("Model printing \n")
print(str(Problem()))

print("Begining MDP building\n")

#list reference to avoid garbage collector
refe=list()

# fill in cost matrix
Reward  = FullMatrix(stateSpace.Cardinal(),actionSpace.Cardinal())

# create instantaneous reward
for x in range(stateSpace.Cardinal()) :
        for q in range(actionSpace.Cardinal()):
                res = 0.0
                if ( q > 0 ) :
                        # case of launching a batch
                        res +=defProb.batchCost
                # loss cost and holding cost
                res=res+max(x-q,0)*defProb.qCost
                Reward.setEntry(x,q,res)


print("Building Transition matrices")
# look over all the actions
for q in range( actionSpace.Cardinal() ) :
        print("Building Transition matrix for action: " + str(q))
        P= SparseMatrix(stateSpace.Cardinal())
        for x in range(stateSpace.Cardinal()) :
                # look over all depart states
                # decision effect
                xt=max(x-q,0)
                for y in range(stateSpace.Cardinal()) :
                        # look over all arrival states
                        proba=0
                        for k in range(xt+1) :
                                # k represents losses
                                if (y-xt+k >= 0):
                                                # k losses occur I am in state xt-k to go to arrival state y there must be y-xt+k arrivals
                                                proba=binomiale(k,xt,defProb.alpha)*poisson(y-xt+k,defProb.lambdaa)
                                else :
                                                proba+=0.0
                                # if y = maxQueueLength then we lost some arrivals
                                if (y==defProb.maxQueueLength) :
                                        for i in range(25) :
                                                l=y+i+1
                                                proba+=binomiale(k,x,defProb.alpha)*poisson(l-x+k,defProb.lambdaa)
                        P.setEntry(x,y,proba)
        refe.append(P)
        #trans[q]=P
        trans.append(P)
        P=None


mdp = DiscountedMDP(critere, stateSpace, actionSpace, trans,Reward,defProb.gamma)
print("End of building MDP")

# entering the transitions matrices
print("Printing MDP")
mdp.Write()

print("Printing solution from value iteration")
# call the function to solve the MDP.
optimum = mdp.ValueIteration(epsilon, maxIter)
optimum.Write()



print("Checking Structural Properties of value")
verifValue =  PropertiesValue(stateSpace)
monotone=verifValue.Monotonicity(optimum)
verifValue.avoidDetail()
print("Printing monotonicity property of value function (1 if increasing -1 if decreasing 0 otherwise) : \n " + str(monotone) + "\n" )

print("Verif convexity with details")
verifValue.getDetail()
convexe=verifValue.Convexity(optimum)
print("Printing convexity property of value function (1 if convex -1 concave 0 otherwise) : \n" + str(convexe) + "\n" )

print("Checking Structural Properties of value")
verifPolitique =  PropertiesPolicy(stateSpace)

monotone=verifPolitique.Monotonicity(optimum)
print("PropertiesPolicy::MonotonicityOptimalPolicy="+str(monotone) + " (1 if increasing -1 if decreasing 0 otherwise) : \n")


print("********************************")
