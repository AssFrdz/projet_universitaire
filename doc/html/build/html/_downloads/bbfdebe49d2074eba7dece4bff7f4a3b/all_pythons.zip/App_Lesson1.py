#!/usr/bin/env python
# coding: utf-8

# # Application Lesson 1: Application to Mitrani's hysteresis model
# <img name="Mitrani_chain.jpg">

# This lesson can be downloaded as a notebook, a notebook for colab and a python file [here](https://marmote.gitlabpages.inria.fr/marmote/python_downloads.html)

# In[1]:


import marmote.core as marmotecore
import marmote.markovchain as marmotemarkovchain
import numpy as np


# ### Picture of the model (credit: Mitrani 2013, Figure 2)

# <img src="./Mitrani_chain.png">

# Defining the constants/parameters of the model

# In[2]:


m = 4          # Number of reserve servers
n = 2          # Number of permanent servers
N = m+n        # Total number of servers
lambda_ = 3.0  # Arrival rate
mu_ = 1.0      # Individual server service rate
nu_ = 5.0      # Inverse of average warmup time of the block of m reserve servers
up = 6         # Upper threshold
down = 4       # Lower threshold
K = 10         # Queue truncation parameter


# In[3]:


space = marmotecore.MarmoteBox( [ 3, K+1 ] )


# In[4]:


space.Enumerate()


# In[5]:


Qtrans = marmotecore.SparseMatrix( space )
Qtrans.set_type( marmotecore.CONTINUOUS )


# In[6]:


Qtrans


# ## Filling the matrix

# ### Naming elements to make code readable

# In[7]:


# naming of coordinates
QUEUE = 1
SERV = 0
# naming of server states
SLOW = 0
WARMING = 1
FAST = 2


# ### Setting up the loop on states

# In[8]:


stateBuffer = space.StateBuffer()
nextBuffer = space.StateBuffer()
space.FirstState(stateBuffer)
idx = 0
print(stateBuffer)


# ### Looping

# In[9]:


looping = True
while looping:
    # print( "Transitions for state ", stateBuffer )
    # convenience local variables, also used for restoring stateBuffer
    q = stateBuffer[QUEUE]
    s = stateBuffer[SERV]

    nextBuffer = np.array(stateBuffer) # copy current state
    # Event: arrivals
    if ( q < K ):
      nextBuffer[QUEUE] += 1;
      if ( ( nextBuffer[QUEUE] > up ) and ( nextBuffer[SERV] == SLOW ) ):
        nextBuffer[SERV] = WARMING;

      Qtrans.addToEntry( idx, space.Index(nextBuffer), lambda_ );
      Qtrans.addToEntry( idx, idx, -lambda_ );

    nextBuffer = np.array(stateBuffer) # copy current state
    # Event: departure
    if ( q > 0 ):
        # number of active servers
        if ( s == FAST ):
            nbServ = min( q, n+m )
        else:
            nbServ = min( q, n )
        nextBuffer[QUEUE] -= 1
        if ( nextBuffer[QUEUE] == down ): # whatever state of server: becomes SLOW
            nextBuffer[SERV] = SLOW;

        Qtrans.addToEntry( idx, space.Index(nextBuffer), mu_ * nbServ )
        Qtrans.addToEntry( idx, idx, -mu_ * nbServ )

    nextBuffer = np.array(stateBuffer) # copy current state
    # Event: end of warmup
    if ( s == WARMING ):
        nextBuffer[SERV] = FAST
        Qtrans.addToEntry( idx, space.Index(nextBuffer), nu_ )
        Qtrans.addToEntry( idx, idx, -nu_ )

    # next state
    space.NextState( stateBuffer )
    idx += 1
    looping = not space.IsFirst(stateBuffer)


# ### Inspecting the matrix. 
# 
# Matrices can be printed using a variety of formats (sparse, Matlab, Maple, numpy).

# In[10]:


print( Qtrans.toString( marmotecore.FORMAT_NUMPY ) )


# The `Diagnose` method produces a summary of various metrics **plus** the structural analysis of the matrix (recurrent/transient classes).

# In[11]:


marmotecore.setStateWritePolicy( marmotecore.STATE_INDEX )
Qtrans.Diagnose()


# Since it is not always simple to relate indices to states, it is also possible to print both the index **and** the state.

# In[12]:


marmotecore.setStateWritePolicy( marmotecore.STATE_BOTH )
Qtrans.Diagnose()


# The connectivity of the state space can be further investigated with the function `IsAccessible()`. This requires creating the Markov chain.

# In[13]:


hymc = marmotemarkovchain.MarkovChain( Qtrans )
hymc.set_model_name( "Hysteresis_box" )


# In[14]:


print( [ hymc.IsAccessible(3,31), hymc.IsAccessible(3,6), hymc.IsAccessible(3,10), 
        hymc.IsAccessible(1,30), hymc.IsAccessible(30,27) ] )


# Whether the chain is irreducible or not is checked with the method `IsIrreducible()`.

# In[15]:


print( hymc.IsIrreducible() )


# ## Stationary distribution and average cost
# 
# Let us compute the stationary distribution.
# This can be done here despite the fact that the chain is not irreducible.

# In[16]:


dista = hymc.StationaryDistribution()


# Inspecting the distribution. As expected, it has many zeroes.

# In[17]:


print(dista)             # Printing a summary of the distribution
print("#")
print(dista.toString())  # Printing the distribution in extenso


# Checking that the distribution is consistent by summing its probabilities.

# In[18]:


total = 0
for i in range(space.Cardinal()):
    total = total + dista.getProbaByIndex(i)
print(total)


# Computing an average linear cost.

# In[19]:


def avg_cost( c1, c2, dis ):
    avgL = 0
    avgS = 0
    space.FirstState(stateBuffer)
    # print(stateBuffer)
    go_on = True
    index = 0
    while go_on:
        prob = dis.getProbaByIndex(index)
        nbServ = n
        if ( stateBuffer[SERV] == FAST ):
            nbServ += m
        avgL = avgL + prob*stateBuffer[QUEUE]
        avgS = avgS + prob*nbServ
        space.NextState(stateBuffer)
        # print(stateBuffer)
        index = index+1
        go_on = not space.IsFirst(stateBuffer)
    return( c1*avgL + c2*avgS )


# In[20]:


cost = avg_cost( 1.0, 1.0, dista )
print(cost)


# ## Tayloring the state space
# 
# The previous approach with a rectangular (box) state space was inefficient, since probabilities had to be computed for non-recurrent states.
# 
# In the following it is shown how to define a state space which fits exactly the recurrent class.

# In[21]:


smaller_space = marmotecore.MarmoteUnionSet()                  # Prepare the construction of the state space as a union
smaller_space.AddSet( marmotecore.MarmoteInterval(0,up) )      # Sub-space with only permanent servers
smaller_space.AddSet( marmotecore.MarmoteInterval(down+1,K) )  # Sub-space with additional servers warming up
smaller_space.AddSet( marmotecore.MarmoteInterval(down+1,K) )  # Sub-space with additional servers running


# In[22]:


smaller_space.Enumerate()


# In[23]:


smaller_space.Cardinal()


# In[24]:


smaller_space.Belongs( [ 2, 3 ] )


# Defining a new matrix on this smaller state space, and filling it.

# In[25]:


Qtrans_alt = marmotecore.SparseMatrix( smaller_space )
Qtrans_alt.set_type( marmotecore.CONTINUOUS )


# In[26]:


# naming of coordinates
QUEUE = 1
SERV = 0
# naming of server states
SLOW = 0
WARMING = 1
FAST = 2
# preparation of buffers
stateBuffer = smaller_space.StateBuffer()
smaller_space.FirstState(stateBuffer)
looping = True
idx = 0
while looping:
    # print( "Transitions for state ", stateBuffer )
    # convenience local variables, also used for restoring stateBuffer
    q = stateBuffer[QUEUE]
    s = stateBuffer[SERV]

    nextBuffer = np.array(stateBuffer) # copy current state
    # Event: arrivals
    if ( q < K ):
      nextBuffer[QUEUE] += 1;
      if ( ( nextBuffer[QUEUE] > up ) and ( nextBuffer[SERV] == SLOW ) ):
        nextBuffer[SERV] = WARMING;

      Qtrans_alt.addToEntry( idx, smaller_space.Index(nextBuffer), lambda_ );
      Qtrans_alt.addToEntry( idx, idx, -lambda_ );
      # print( stateBuffer, " to ", nextBuffer )
      # print( smaller_space.Belongs(nextBuffer), smaller_space.Index(nextBuffer) )

    nextBuffer = np.array(stateBuffer) # copy current state
    # Event: departure
    if ( q > 0 ):
        # number of active servers
        if ( s == FAST ):
            nbServ = min( q, n+m )
        else:
            nbServ = min( q, n )
        nextBuffer[QUEUE] -= 1
        if ( nextBuffer[QUEUE] == down ): # whatever state of server: becomes SLOW
            nextBuffer[SERV] = SLOW;

        Qtrans_alt.addToEntry( idx, smaller_space.Index(nextBuffer), mu_ * nbServ )
        Qtrans_alt.addToEntry( idx, idx, -mu_ * nbServ )

    nextBuffer = np.array(stateBuffer) # copy current state
    # Event: end of warmup
    if ( s == WARMING ):
        nextBuffer[SERV] = FAST
        Qtrans_alt.addToEntry( idx, smaller_space.Index(nextBuffer), nu_ )
        Qtrans_alt.addToEntry( idx, idx, -nu_ )

    # next state
    smaller_space.NextState( stateBuffer )
    idx += 1
    looping = not smaller_space.IsFirst(stateBuffer)


# In[27]:


print( Qtrans_alt.toString( marmotecore.FORMAT_NUMPY ) )


# Using the "full state" feature to inspect in detail the transitions.

# In[28]:


print( Qtrans_alt.toString( marmotecore.FORMAT_FULLSTATE ) )


# Looking at the structural analysis.
# 
# Now all states are recurrent.

# In[29]:


Qtrans_alt.Diagnose()


# Indeed, irreducibility can be tested on Markov chains with the `IsIrreducible()` method.

# In[30]:


hymc_alt = marmotemarkovchain.MarkovChain( Qtrans_alt )
print( hymc_alt.IsIrreducible() )                        # The new chain is irreducible
print( hymc.IsIrreducible() )                            # The old one is not


# Computing the stationary distribution of this new chain, checking that it is consistent, then computing the average cost.

# In[31]:


dista_alt = hymc_alt.StationaryDistribution()


# In[32]:


print(dista_alt)
total = 0
for i in range(smaller_space.Cardinal()):
    total = total + dista_alt.getProbaByIndex(i)
print(total)


# In[33]:


def avg_cost_alt( c1, c2, dis ):
    avgL = 0
    avgS = 0
    smaller_space.FirstState(stateBuffer)
    # print(stateBuffer)
    go_on = True
    index = 0
    while go_on:
        prob = dis.getProbaByIndex(index)
        nbServ = n
        if ( stateBuffer[SERV] == FAST ):
            nbServ += m
        avgL = avgL + prob*stateBuffer[QUEUE]
        avgS = avgS + prob*nbServ
        smaller_space.NextState(stateBuffer)
        # print(stateBuffer)
        index = index+1
        go_on = not smaller_space.IsFirst(stateBuffer)
    return( c1*avgL + c2*avgS )


# In[34]:


cost_alt = avg_cost_alt( 1.0, 1.0, dista_alt )


# In the end we have the same cost

# In[35]:


print(cost_alt)
print( cost )


# End of App_Lesson1.
