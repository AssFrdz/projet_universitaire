#!/usr/bin/env python
# coding: utf-8

# # Lesson 3: working with state spaces

# This lesson can be downloaded as a notebook, a notebook for colab and a python file [here](https://marmote.gitlabpages.inria.fr/marmote/python_downloads.html)

# In[1]:


import marmote.core as marmotecore
import marmote.markovchain as mmc
import numpy as np


# State spaces for `Marmote`'s Markov chains are specified with `MarmoteSet` objects.
# This lesson presents the principal features of this object, and the currently available implementations.

# ## Functionalities of MarmoteSet: example with intervals and boxes

# Basic sets in `Marmote` are intervals and "boxes": the object classes are
# `MarmoteInterval` and `MarmoteBox`.

# Creation of an (integer) interval between 0 and 6 included.

# In[2]:


itl = marmotecore.MarmoteInterval(0,6)


# In[3]:


print( "name = ", itl.className())
print( "cardinal = ", itl.Cardinal())
print(itl)


# Creation of a 2-d box with size 2 in the first dimension and 3 in the second one.
# Note that ranges will be 0..1 and 0..2.

# In[4]:


box = marmotecore.MarmoteBox( [ 2, 3 ] )


# Inspecting the propreties of the object

# In[5]:


print( "name = ", box.className())
print( "cardinal = ", box.Cardinal())
print(box)


# Listing all the states

# In[6]:


box.Enumerate()


# ## States and their indices

# Every state has an index and conversely. Indices range from 0 to Cardinal()-1.
# The relevant methods are:
# 
# * `Index( state )` to get the index of some state
# * `DecodeState( idx )` to get the state corresponding to some index

# In[7]:


box.Index( [1,0] )


# In[8]:


box.DecodeState( 4 )


# ### Printing states

# When printing states, it is possible to get both its index information and its description.
# 
# `Marmote` has a "policy" for writing states which is controlled as follows. First we save the current policy
# using the method `stateWritePolicy()`.

# In[9]:


polsave = marmotecore.stateWritePolicy()


# Next we manipulate the way states are printed with the method `setStateWritePolicy()`. We set in sequence the policy to its three possible values: `STATE_INDEX`, `STATE_BOTH` and `STATE_FULL`.

# In[10]:


marmotecore.setStateWritePolicy( marmotecore.STATE_INDEX )
print( "Format with index: ", box.FormatState( 4 ) )
marmotecore.setStateWritePolicy( marmotecore.STATE_BOTH )
print( "Format with both: ", box.FormatState( 4 ) )
marmotecore.setStateWritePolicy( marmotecore.STATE_FULL )
print( "Format with full description: ", box.FormatState( 4 ) )


# Finally we restore the policy to what it was previously.

# In[11]:


marmotecore.setStateWritePolicy(polsave)


# ### Checking membership

# Membership is tested with the method `Belongs`.

# In[12]:


print( itl.Belongs( np.array([4]) ) )    # 4 is in [0..6]
print( itl.Belongs( np.array([40]) ) )   # 40 is not
print( box.Belongs( np.array([4,4]) ) )  # a state outside the 2-d box
print( box.Belongs( np.array([1,1]) ) )  # a state inside


# ### Looping through the states

# The easiest way to loop through all states is to use a `for` loop.
# It enumerates the states in the form: (index, array representation).

# In[13]:


for s in box:
    print(s)


# There exist other ways to inspect `MarmoteSet` objects and make the correspondence between *states* and *indices*.
# The following one uses the standard way to walk through a set using methods:
# 
# * `FirstState(state)` to initialize the state to the "zero state"
# * `Index(state)` to convert a state to its index
# * `NextState(state)` to move the state its follower in the set's order
# * `IsFirst(state)` to test if the state is the "zero state".
#   
# All use a `state` variable which is an array of integers. Some methods *modify* this array.

# In[14]:


marmotecore.setStateWritePolicy( marmotecore.STATE_BOTH )
bbuf = box.StateBuffer()
box.FirstState(bbuf)           # the buffer is modified!
print(bbuf)
isover = False
while not isover:
    idx = box.Index(bbuf)
    print( box.FormatState( box.Index(bbuf) ) )
    box.NextState(bbuf)        # the buffer is modified!
    isover = box.IsFirst(bbuf)


# ## Other sets

# The complete hierarchy of `MarmoteSet` objects is currently:
# 
# * `EmptySet`
# * `MarmoteInterval`
#   + `Integers`
# * `MarmoteBox`
# * `BinarySequence`
# * `BinarySimplex`
# * `Simplex`

# ### Binary sequences

# In[15]:


biseq = marmotecore.BinarySequence( 6 )


# In[16]:


print( "name = ", biseq.className())
print( "cardinal = ", biseq.Cardinal())
biseq.Enumerate()


# In[17]:


bbuf = biseq.StateBuffer()
biseq.FirstState(bbuf)
isover = False
while not isover:
    print( biseq.FormatState( biseq.Index(bbuf) ) )
    biseq.NextState(bbuf)
    isover = biseq.IsFirst(bbuf)


# Illustration of membership tests. When a state does not belong to the set, its index is 0 by convention and a warning is issued.

# In[18]:


st1 = np.array( [1, 0, 1, 1, 0, 1], dtype=int )
print( biseq.Belongs( st1 ) )
print( biseq.Index( st1 ) )


# In[19]:


st2 = np.array( [2, 4, 1, 1, 0, 1], dtype=int )
print( biseq.Belongs( st2 ) )
print( biseq.Index( st2 ) )


# ### The set of integers

# `Marmote` has also a set for all integers!

# In[20]:


itg = marmotecore.MarmoteIntegers()


# In[21]:


print( "name = ", itg.className())
print( "cardinal = ", itg.Cardinal()) ## -2 is the convention for 'infinite cardinal'
print( itg.IsFinite() )


# Membership tests

# In[22]:


print( itg.Belongs( [4] ) )
print( itg.Belongs( [-3] ) )


# In[23]:


print( itg.Index( [-3] ) )


# ### Simplices

# Simplex sets are sometimes difficult to enumerate. Not with `Marmote`!

# In[24]:


splx = marmotecore.Simplex( 7, 3 )


# In[25]:


splx.Enumerate()


# In[26]:


print( splx.Belongs( [ 0, 0, 0, 0, 0, 0 ] ) )
print( splx.Belongs( [ 0, 0, 0, 0, 0, 0, 3 ] ) )
print( splx.Belongs( [ 0, -1, 1, 0, 0, 0, 3 ] ) )


# In[27]:


bsplx = marmotecore.BinarySimplex( 7, 3 )


# In[28]:


bsplx.Enumerate()


# More set manipulations to be seen in App_Lesson1!
