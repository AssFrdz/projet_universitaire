#!/usr/bin/env python
# coding: utf-8

# # Lesson 5: Predefined Markov Chains

# This lesson can be downloaded as a notebook, a notebook for colab and a python file [here](https://marmote.gitlabpages.inria.fr/marmote/python_downloads.html)

# In[1]:


import marmote.core as marmotecore
import marmote.markovchain as mmc
import numpy as np


# Some of the well-known Markov models are implemented in `Marmote` as objects heritating from `MarkovChain`. Their current list is:
# 
# * `TwoStateDiscrete`
# * `TwoStateContinuous`
# * `Homogeneous1DRandomWalk`
# * `Homogeneous1DBirthDeath`
#   * `PoissonProcess`
# * `HomogeneousMultiDRandomWalk`
# * `HomogeneousMultiDBirthDeath`
# * `MMPP` 

# ## The continuous-time birth-death process

# ### Infinite-state birth-death process

# In[2]:


mc = mmc.Homogeneous1DBirthDeath( 0.5, 1.0 )


# Although it has theoretically an infinite state space, this chain can be simulated.
# 
# Simulating the chain with options:
# 
# * 10.0 units of time
# * no stats collected
# * no trajectory kept in memory
# * trajectory printed along the way
# * increments in times displayed as well

# In[3]:


simres = mc.SimulateChain( 10.0, stats=False, traj=False, progress=True, withIncrements=True )


# Computing the stationary distribution. It is well-known that this distribution is geometric.

# In[4]:


stadis = mc.StationaryDistribution()


# In[5]:


print(stadis)
print(stadis.Mean())
print(stadis.getProba(0))
print(stadis.getProba(1))
print(stadis.Ccdf(4))


# Embedding and Uniformizing.
# 
# Uniformizing results in another well-known Markov chain.

# In[6]:


umc = mc.Uniformize()
print(umc.className())


# However embedding does not result in a standard Markov chain.

# In[7]:


mc.Embed()


# ### Finite-space birth-death proces

# A birth-death process with 11 states

# In[8]:


mcf = mmc.Homogeneous1DBirthDeath( 11, 0.4, 0.8 )


# In[9]:


stadisf = mcf.StationaryDistribution()


# In[10]:


print(stadisf)


# In[11]:


print(stadisf.Mean())
print(stadisf.getProba(0))
print(stadisf.getProba(1))
print(stadisf.Ccdf(4))


# Investigating hitting times.
# 
# First set up the hitting set. Here, states 3 and 7 are in the set: \[ - - - X - - - X - - - \]

# In[12]:


hitSet = np.zeros( [11], dtype=bool)
hitSet[3] = True
hitSet[7] = True
print(hitSet)


# Average hitting times are computed (numerically in this case).

# In[13]:


avg = mcf.AverageHittingTimes( hitSet )
print(avg)


# Also available, joint expected hitting time and hitting state: E( tau * ind(X(tau)=s) )

# In[14]:


avgcon = mcf.AverageHittingTimes_Conditional( hitSet )
print( avgcon[0:10,2:8] )


# Also available: simulation of hitting times.

# In[15]:


simres = mcf.SimulateHittingTime( 0, hitSet, 20, 10000 )


# In[16]:


simres.Diagnose()


# In[17]:


print(simres.CT_dates())


# ### Multidimensional birth-death

# Consider a 3-d birth-death process on a 4 x 4 x 4 box.
# 
# The constructor to `HomogeneousMultiDBirthDeath` has arguments: sizes, birth rates, death rates.

# In[18]:


mdbd = mmc.HomogeneousMultiDBirthDeath( [ 4, 4, 4 ], [ 1.0, 1.0, 1.0], [ 0.8, 0.8, 0.2 ] )


# In[19]:


simres = mdbd.SimulateChain( 10.0, stats=True, traj=False, withIncrements=True, progress=True )


# Statistics can be performed on this trajectory also

# In[20]:


sd = simres.Distribution()


# ## Arrival processes

# There are two pure arrival processes in `Marmote`: `PoissonProcess` and `MMPP`.

# In[21]:


poi = mmc.PoissonProcess( 1.0 )


# In[22]:


simres = poi.SimulateChain( 10.0, False, True, True )


# Creating an MMPP with modulating chain the 8-state birth-death of this lesson. Arrival rates are 0 except in states 1 and 7.

# In[23]:


mmpp = mmc.MMPP( mcf.generator(), [ 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0 ] )


# Simulation stating from 0 arrivals and state 0 of the environment. 
# 
# Coding of 'state' trajectory (experimental) is 2*nb of arrivals + current state of the environment.

# In[24]:


simres = mmpp.SimulateChain( 10.0, marmotecore.DiracDistribution(0.0), marmotecore.DiracDistribution(0.0), False, True, True )


# In[ ]:




